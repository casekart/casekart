<!DOCTYPE html>
<html lang="en">
<head>
   <link rel="shortcut icon" href="img/favicon.png">

    <title>Login Page</title>

    <!-- Bootstrap CSS -->    
    <link href="/template_generator/css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="/template_generator/css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="/template_generator/css/elegant-icons-style.css" rel="stylesheet" />
    <link href="/template_generator/css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="/template_generator/css/style.css" rel="stylesheet">
    <link href="/template_generator/css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>

  <!-- <body class="login-img3-body"> -->

    <div class="container">
        <div class="alert alert-danger" style="display:none;">
        <strong>Please contact admin</strong>
      </div> 
      <form class="login-form" action="index.html">        
        <div class="login-wrap">
            <p class="login-img"><i class="icon_lock_alt"></i></p>
            <div class="input-group">
              <span class="input-group-addon"><i class="icon_profile"></i></span>
              <input type="text" class="form-control" name="username" id="username" placeholder="Username" autofocus>
            </div>
            <div class="input-group">
                <span class="input-group-addon"><i class="icon_key_alt"></i></span>
                <input type="password" class="form-control" id="password" name="password" placeholder="Password">
            </div>
            <label class="checkbox">
                <input type="checkbox" value="remember-me"> Remember me
                <span class="pull-right"> <a href="#"> Forgot Password?</a></span>
            </label>
            <button class="btn btn-primary btn-lg btn-block" id="login" type="submit">Login</button>
      </div>
      </form>
  </div>
</body>
</html>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script>
jQuery('#login').on('click',function(){
       var formdata = 
    {
        username: jQuery('#username').val(),
        password: jQuery('#password').val(),
    };
    jQuery.ajax({
      url: "admindashboard/login",
      dataType: 'json',
      type: 'POST',
      data: formdata,    
      success: function(login){
        // alert(login);
        if(login.status === true){
          var url = login.redirect;
          document.location.href = url.replace(/\\/g, '');
        }
        else if(login === "Contact admin"){
          $('.alert-danger').css('display','block');           
        }
      }
    });
    return false;
  });
</script>