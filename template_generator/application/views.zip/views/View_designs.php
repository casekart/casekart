<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Upload Images</title>

    <!-- Bootstrap CSS -->    
    <link href="/template_generator/css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="/template_generator/css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="/template_generator/css/elegant-icons-style.css" rel="stylesheet" />
    <link href="/template_generator/css/font-awesome.min.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="/template_generator/css/style.css" rel="stylesheet">
    <link href="/template_generator/css/style-responsive.css" rel="stylesheet" />
    <link href="/template_generator/css/Dashboard.css" rel="stylesheet" />
    <link href="/template_generator/css/bootstrap.css" rel="stylesheet" />
    <link href="/template_generator/css/hoverbox.css" rel="stylesheet" />
    <link href='http://fonts.googleapis.com/css?family=Quicksand:700' rel='stylesheet' type='text/css'>
  </head>
  <body>
<section id="container" class="">
     
      
      <header class="header dark-bg">
            <div class="toggle-nav">
                <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
            </div>

            <!--logo start-->
            <a href="#" class="logo"><span class="lite">Welcome</span></a>
            <!--logo end-->

            <div class="nav search-row" id="top_menu">                
            </div>

            <div class="top-nav notification-row">                
                <!-- notificatoin dropdown start-->
                <ul class="nav pull-right top-menu">
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="profile-ava">
                                <img alt="" src="img/avatar1_small.jpg">
                            </span>
                            <span class="username"></span>
                            <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu extended logout">
                            <div class="log-arrow-up"></div>
                            <li>
                                <a href="http://www.casekart.com/template_generator/index.php/admindashboard"><i class="icon_key_alt"></i> Log Out</a>
                            </li>
                        </ul>
                    </li>
                    <!-- user login dropdown end -->
                </ul>
                <!-- notificatoin dropdown end-->
            </div>
      </header>      
      <aside>
          <div id="sidebar"  class="nav-collapse ">
             <ul class="sidebar-menu">                
                  
                  <li class="sub-menu">
                      <a href="http://www.casekart.com/template_generator/index.php/customerorder" class="">
                          <i class="icon_documents_alt"></i>
                          <span>Order</span>
                          <span class="arrow_carrot-right"></span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="http://www.casekart.com/template_generator/index.php/customerimage" class="">
                          <i class="icon_documents_alt"></i>
                          <span>Upload Designs</span>
                          <span class=" arrow_carrot-right"></span>
                      </a>
                  </li>
                <li class="sub-menu">
                      <a href="http://www.casekart.com/template_generator/index.php/add_models" class="">
                          <i class="icon_documents_alt"></i>
                          <span>Add Mobiles</span>
                          <span class=" arrow_carrot-right"></span>
                      </a>
                  </li>
                   <li class="sub-menu">
                      <a href="http://www.casekart.com/template_generator/index.php/add_brands" class="">
                          <i class="icon_documents_alt"></i>
                          <span>Add Brands</span>
                          <span class=" arrow_carrot-right"></span>
                      </a>
                  </li> 
                  <li class="sub-menu">
                      <a href="http://www.casekart.com/template_generator/index.php/add_brands" class="">
                          <i class="icon_documents_alt"></i>
                          <span>View Designs</span>
                          <span class=" arrow_carrot-right"></span>
                      </a>
                  </li> 
              </ul>
         </div>
      </aside>
      <!--sidebar end-->

      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <h2>Uploaded Images</h2>
              <!-- page end-->
            </section>
<div id="images"></div>
      <!--main content end-->
  </section>
  <!-- container section end -->
    <!-- javascripts -->
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.js"></script>
<script type="text/javascript" src="/template_generator/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/template_generator/js/ajaxupload.js"></script>
<script src="/template_generator/js/jquery.scrollTo.min.js"></script>
<script src="/template_generator/js/jquery.nicescroll.js" type="text/javascript"></script>
<!-- <script src="/template_generator/js/common.js" type="text/javascript"></script> -->
<script src="/template_generator/js/scripts.js"></script>
<script>
$(document).ready(function(){
  $.ajax({
    url :"imageupload/image",
    dataType:'json',
    success:function(data){
      $.each(data,function(index,value){
        $('#images').append(
          '<ul class="hoverbox"><li><div class="image_'+value.id+'">'+
          '<input type="checkbox" name="checkbox" value="'+value.id+'" id="checkbox" style="display:none"/>'+
          '<input type="checkbox" name="img" value="'+value.image_name+'" id="iname" style="display:none"/>'+
          '<img class="preview" src="/Designbnk_bp/assets/image/'+value.image_name+'"></li></ul>'+
          '</div>'
          );
      });
    }
  });
});
$('#images').on('click','img',function(){
  var formdata = {
    checked_id : $(this).parent().find('#checkbox').val(),
    img : $(this).parent().find('#iname').val(),
  };
  $.ajax({
    type:"POST",
    url:"imageupload/delete",
    data: formdata,
    dataType: 'JSON',
    success:function(data){
      $('.image_'+formdata.checked_id).css('display','none');
      alert('Deleted');
    }
  });

}); 
</script>
</body>
</html>
