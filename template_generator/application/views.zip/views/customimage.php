<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Upload Images</title>

    <!-- Bootstrap CSS -->    
    <link href="/template_generator/css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="/template_generator/css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="/template_generator/css/elegant-icons-style.css" rel="stylesheet" />
    <link href="/template_generator/css/font-awesome.min.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="/template_generator/css/style.css" rel="stylesheet">
    <link href="/template_generator/css/style-responsive.css" rel="stylesheet" />
    <link href="/template_generator/css/Dashboard.css" rel="stylesheet" />
    <link href="/template_generator/css/bootstrap.css" rel="stylesheet" />
    <link href='http://fonts.googleapis.com/css?family=Quicksand:700' rel='stylesheet' type='text/css'>


    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
      <script src="js/lte-ie7.js"></script>
    <![endif]-->
  </head>

  <body>
<section id="container" class="">
     
      
      <header class="header dark-bg">
            <div class="toggle-nav">
                <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
            </div>

            <!--logo start-->
            <a href="#" class="logo"><span class="lite">Welcome</span></a>
            <!--logo end-->

            <div class="nav search-row" id="top_menu">
                <!--  search form start -->
                <!-- <ul class="nav top-menu">                    
                    <li>
                        <form class="navbar-form">
                            <input class="form-control" placeholder="Search" type="text"/>
                        </form>
                    </li>                    
                </ul> -->
                <!--  search form end -->                
            </div>

            <div class="top-nav notification-row">                
                <!-- notificatoin dropdown start-->
                <ul class="nav pull-right top-menu">
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="profile-ava">
                                <img alt="" src="img/avatar1_small.jpg">
                            </span>
                            <span class="username">Jenifer Smith</span>
                            <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu extended logout">
                            <div class="log-arrow-up"></div>
                            <li>
                                <a href="http://www.casekart.com/template_generator/index.php/admindashboard"><i class="icon_key_alt"></i> Log Out</a>
                            </li>
                        </ul>
                    </li>
                    <!-- user login dropdown end -->
                </ul>
                <!-- notificatoin dropdown end-->
            </div>
      </header>      
      <aside>
          <div id="sidebar"  class="nav-collapse ">
             <ul class="sidebar-menu">                
                  
                  <li class="sub-menu">
                      <a href="http://www.casekart.com/template_generator/index.php/customerorder" class="">
                          <i class="icon_documents_alt"></i>
                          <span>Order</span>
                          <span class="arrow_carrot-right"></span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="http://www.casekart.com/template_generator/index.php/customerimage" class="">
                          <i class="icon_documents_alt"></i>
                          <span>Upload Designs</span>
                          <span class=" arrow_carrot-right"></span>
                      </a>
                  </li>
                <li class="sub-menu">
                      <a href="http://www.casekart.com/template_generator/index.php/add_models" class="">
                          <i class="icon_documents_alt"></i>
                          <span>Add Mobiles</span>
                          <span class=" arrow_carrot-right"></span>
                      </a>
                  </li>
                   <li class="sub-menu">
                      <a href="http://www.casekart.com/template_generator/index.php/add_brands" class="">
                          <i class="icon_documents_alt"></i>
                          <span>Add Brands</span>
                          <span class=" arrow_carrot-right"></span>
                      </a>
                  </li> 
                  <li class="sub-menu">
                      <a href="http://www.casekart.com/template_generator/index.php/ViewDesigns" class="">
                          <i class="icon_documents_alt"></i>
                          <span>View Designs</span>
                          <span class=" arrow_carrot-right"></span>
                      </a>
                  </li> 
              </ul>
         </div>
      </aside>
      <!--sidebar end-->

      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
            <div class="row">
                <div class="col-lg-12">
              <!-- page start-->
              <h2>Upload Images</h2>
              <!-- page end-->
  <div class="row">
  <div class="col-sm-12 col-md-12 col-lg-12 main">
<div id="upload" class="col-lg-8 col-lg-offset-2 col-xs-12 col-sm-12 col-md-8 col-md-offset-2 upload">
    <div class="panel panel-default">
      <div class="panel-heading">Select and Upload
      </div>
      <div class="panel-body">
        <div class="row">
        <div class="col-lg-4">
        <div class="form-group">
          <form method="post" class="form"/>
          <div class="form-group" >
            <div class="col-md-2">
              <div  class="custom1">
                <label>Catogery Name:
                <input class="input_file" type="text" name="catagory" placeholder="Enter Catogery" required></input>
              </label>
              <!-- <input class="custom input_file1"></input> -->
            </div>
              <div class="custom2">            
              <!-- <input class="custom input_file"placeholder="Browse to upload image" ><span id="ulList"></span></input>           -->
              <input type="hidden" name="form_submit" value="1">
              <input class="customN  input_file1" type="file" value="#images" data-input="false" data-classIcon="icon-plus" name="images[]" id="image" multiple><span id='val'>
              
             </div>
            
          </span> <span></span></input>
              <input type="submit" onclick="FileDetails()"value="Upload" class="btn btn btn-default submit1" name="upload1" id="upload1"/>
          </div></div>
 </form>
</div>

</div>
</div>
</div>
</section>
</section>
  <!-- container section end -->
    <!-- javascripts --> 
<link class="jsbin" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1/themes/base/jquery-ui.css" rel="stylesheet" type="text/css" />
<script class="jsbin" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script class="jsbin" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.0/jquery-ui.min.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.js"></script>
<script type="text/javascript" src="/template_generator/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/template_generator/js/ajaxupload.js"></script>
<script src="/template_generator/js/jquery.scrollTo.min.js"></script>
<script type="text/javascript" src="/template_generator/js/bootstrap-filestyle.min.js"> </script>
<script src="/template_generator/js/jquery.nicescroll.js" type="text/javascript"></script>
<!-- <script src="/template_generator/js/common.js" type="text/javascript"></script> -->
<script src="/template_generator/js/scripts.js"></script>
<script>
$(document).ready(function (e) {
 $('.form').on('submit',function(e) {
   e.preventDefault();
   $.ajax({
    url: "imageupload/do_upload",        
    type: "POST",             
    data: new FormData(this), 
    contentType: false,       
    cache: false,            
    processData:false,        
    dataType: 'JSON',
    success: function(data) {
      $.each(data.image_list,function(key,rows){
        $.each(rows,function(index,value){
          $('#images').append(  
            '<div class="image_'+value.id+'">'+
            '<input type="checkbox" name="checkbox" value="'+value.id+'" id="checkbox" style="display:none"/> </div>'+
            '<input type="checkbox" name="img" value="'+value.image_name+'" id="iname" style="display:none"/>'+
            '<img src="/Designbnk_bp/assets/image/'+value.image_name+'">'+
            '</div>'
            );
        });
      });
      if (data.error) {alert(data.error);};
       }
  });
 });
 return false;
}); 
$("#image").click(function () {
    $(":file").filestyle();
});

</script>
</body>
</html>
